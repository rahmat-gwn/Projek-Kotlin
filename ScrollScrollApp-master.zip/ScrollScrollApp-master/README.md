# ScrollScrollApp

Tugas Pertama Android
- Membuat list memakai RecyclerView
- Ketika listnya diclick akan ke halaman detail
